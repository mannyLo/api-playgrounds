import UIKit
import Foundation

let apiKey = "703dc9aaa3854eae81def58ae4595688"
let year = 1968 //int from 1851 - 2017
let month = 6 //int 1 - 12
let urlString = "https://api.nytimes.com/svc/archive/v1/\(year)/\(month).json?api-key=\(apiKey)"
let url = URL(string: urlString)

//print(urlString)

//Structs
struct Initial: Decodable {
  let response: Response
}

struct Response: Decodable {
  let meta: Meta
  let article: [Article]
  
  enum CodingKeys: String, CodingKey {
    case article = "docs"
    case meta
  }
}

struct Article: Decodable {
  let headline: Headlines
  let snippet: String?
  let date: String
  let url: URL

  enum CodingKeys: String, CodingKey {
    case headline
    case snippet
    case date = "pub_date"
    case url = "web_url"
  }
}

struct Meta: Decodable {
  let hits: Int
}

struct Headlines: Decodable {
  let main: String
}

//Main Method
let task = URLSession.shared.dataTask(with: url!) {(data, response, err) in

  guard let data = data else {
    print("No Data to Decode")
    return
  }

  guard let result = try? JSONDecoder().decode(Initial.self, from: data) else {
    print("Error in Decoding Data")
    return
  }
  
  print("Total Hits")
  print("- \(result.response.meta.hits)")
  print("---------------------------")
  let first = result.response.article[0]
  print("Headline: \(first.headline.main)")
  print("Snippet: \(first.snippet ?? "None")")
  print("Date: \(first.date)")
  print("URL: \(first.url)")
//  for article in result.response.article {
//    print("Headline: \(article.headline.main)")
//    print("Snippet: \(article.snippet ?? "None")")
//    print("Date: \(article.date)")
//    print("URL: \(article.url)")
//  }
}

task.resume()

