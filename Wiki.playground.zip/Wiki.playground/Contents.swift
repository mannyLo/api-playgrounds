import UIKit
import Foundation

let month = 10 //int 1 - 12
let day = 22 //int 1 - 31
let urlString = "http://history.muffinlabs.com/date/\(month)/\(day)"
let url = URL(string: urlString)


struct Response: Decodable {
  let date:String
  let data:ResponseData
}

struct ResponseData: Decodable {
  let events: [Event]
  let births: [Birth]
  let deaths: [Death]
  
  enum CodingKeys: String, CodingKey {
    case events = "Events"
    case births = "Births"
    case deaths = "Deaths"
  }
}

struct Event: Decodable {
  let year:String
  let headline:String
  let links: [Link]
  
  enum CodingKeys:String, CodingKey {
    case year
    case headline = "text"
    case links
  }
}

struct Birth: Decodable {
  let year:String
  let person:String
  let links: [Link]
  
  enum CodingKeys:String, CodingKey {
    case year
    case person = "text"
    case links
  }
}

struct Death: Decodable {
  let year:String
  let person:String
  let links: [Link]
  
  enum CodingKeys:String, CodingKey {
    case year
    case person = "text"
    case links
  }
}

struct Link: Decodable {
  let title:String
  let url:String
  
  enum CodingKeys: String, CodingKey {
    case title
    case url = "link"
  }
}


let task = URLSession.shared.dataTask(with: url!) {(data, response, err) in

  guard let data = data else {
    print("No Data to Decode")
    return
  }

  guard let result = try? JSONDecoder().decode(Response.self, from: data) else {
    print("Error in Decoding Data")
    return
  }
  
//  EVENTS
  let events = result.data.events
  print("Date: \(result.date)")
  print("----------------------")
  for event in events {
    print("Year: \(event.year)")
    print("Headline: \(event.headline)")
    let links = event.links
    for link in links {
      print("- Title: \(link.title)")
      print("- Link: \(link.url)")
    }
    print("\n")
  }
  
//  BIRTHS
//  let births = result.data.births
//  print("Date: \(result.date)")
//  print("----------------------")
//  for birth in births {
//    print("Year: \(birth.year)")
//    print("Person: \(birth.person)")
//    let links = birth.links
//    for link in links {
//      print("- Title: \(link.title)")
//      print("- Link: \(link.url)")
//    }
//    print("\n")
//  }
  
//  DEATHS
//  let deaths = result.data.deaths
//  print("Date: \(result.date)")
//  print("----------------------")
//  for death in deaths {
//    print("Year: \(death.year)")
//    print("Person: \(death.person)")
//    let links = death.links
//    for link in links {
//      print("- Title: \(link.title)")
//      print("- Link: \(link.url)")
//    }
//    print("\n")
//  }

}

task.resume()
